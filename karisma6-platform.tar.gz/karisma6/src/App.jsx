import { BrowserRouter, Routes, Route, Navigate } from 'react-router-dom'
import { AuthProvider } from './lib/auth'
import { ProtectedRoute, PublicOnlyRoute } from './components/layout/ProtectedRoute'

// Pages
import Home from './pages/Home'
import Login from './pages/Login'
import Register from './pages/Register'
import Registration from './pages/Registration'
import { ForgotPassword, ResetPassword } from './pages/Auth'

// Dashboard pages
import Dashboard from './pages/dashboard/Dashboard'
import {
  DashboardRegistration,
  DashboardPayment,
  DashboardSubmission,
  DashboardCertificate,
  DashboardAnnouncements,
} from './pages/dashboard'

// Admin pages
import { AdminPaymentRecap, AdminCertificates } from './pages/admin'

export default function App() {
  return (
    <AuthProvider>
      <BrowserRouter>
        <Routes>
          {/* Public routes */}
          <Route path="/" element={<Home />} />
          <Route path="/registration" element={<Registration />} />

          {/* Auth routes (redirect if logged in) */}
          <Route path="/login" element={<PublicOnlyRoute><Login /></PublicOnlyRoute>} />
          <Route path="/register" element={<PublicOnlyRoute><Register /></PublicOnlyRoute>} />
          <Route path="/forgot-password" element={<PublicOnlyRoute><ForgotPassword /></PublicOnlyRoute>} />
          <Route path="/reset-password" element={<ResetPassword />} />

          {/* Participant dashboard */}
          <Route path="/dashboard" element={<ProtectedRoute><Dashboard /></ProtectedRoute>} />
          <Route path="/dashboard/registration" element={<ProtectedRoute><DashboardRegistration /></ProtectedRoute>} />
          <Route path="/dashboard/payment" element={<ProtectedRoute><DashboardPayment /></ProtectedRoute>} />
          <Route path="/dashboard/submission" element={<ProtectedRoute><DashboardSubmission /></ProtectedRoute>} />
          <Route path="/dashboard/certificate" element={<ProtectedRoute><DashboardCertificate /></ProtectedRoute>} />
          <Route path="/dashboard/announcements" element={<ProtectedRoute><DashboardAnnouncements /></ProtectedRoute>} />

          {/* Admin routes */}
          <Route path="/admin/payment-recap" element={<ProtectedRoute adminOnly><AdminPaymentRecap /></ProtectedRoute>} />
          <Route path="/admin/certificates" element={<ProtectedRoute adminOnly><AdminCertificates /></ProtectedRoute>} />

          {/* Catch-all */}
          <Route path="*" element={<Navigate to="/" replace />} />
        </Routes>
      </BrowserRouter>
    </AuthProvider>
  )
}
