// Standalone /registration page (public-facing competition registration details)
import { Link } from 'react-router-dom'
import { ArrowRight, Calendar, Users, DollarSign } from 'lucide-react'
import Navbar from '../components/layout/Navbar'
import { COMPETITIONS, formatCurrency } from '../lib/data'

export default function Registration() {
  return (
    <div className="min-h-screen bg-navy-900">
      <Navbar />
      <div className="pt-24 pb-20 max-w-6xl mx-auto px-4">
        <div className="text-center mb-14">
          <p className="text-gold-400 text-sm font-medium tracking-widest uppercase mb-3">Ikuti Kompetisi</p>
          <h1 className="font-display font-black text-4xl md:text-5xl text-white mb-4">
            Pendaftaran <span className="text-gradient">KARISMA 6</span>
          </h1>
          <p className="text-gray-400 text-lg max-w-2xl mx-auto">
            Pilih kategori yang sesuai dengan bidang keahlian Anda dan daftarkan tim terbaik Anda.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {COMPETITIONS.map(comp => (
            <div key={comp.id} className={`card border ${comp.border} bg-gradient-to-br ${comp.color} flex flex-col`}>
              <div className="text-4xl mb-3">{comp.icon}</div>
              <span className="badge badge-info text-xs mb-3 self-start">{comp.category}</span>
              <h3 className="font-display font-bold text-white text-lg mb-2">{comp.name}</h3>
              <p className="text-gray-400 text-sm leading-relaxed mb-5 flex-1">{comp.description}</p>

              <div className="space-y-2 text-sm mb-5">
                <div className="flex items-center gap-2 text-gray-400">
                  <Users size={14} className="text-gray-500" />
                  Maks. {comp.maxTeam} anggota per tim
                </div>
                <div className="flex items-center gap-2 text-gray-400">
                  <Calendar size={14} className="text-gray-500" />
                  Deadline: {new Date(comp.deadline).toLocaleDateString('id-ID', { dateStyle: 'long' })}
                </div>
                <div className="flex items-center gap-2 text-gold-400 font-medium">
                  <DollarSign size={14} />
                  {formatCurrency(comp.fee)}
                </div>
              </div>

              <Link to="/register" className="btn-primary w-full justify-center text-sm">
                Daftar Sekarang <ArrowRight size={14} />
              </Link>
            </div>
          ))}
        </div>

        <div className="text-center mt-12 text-gray-500 text-sm">
          Sudah punya akun?{' '}
          <Link to="/login" className="text-gold-400 hover:text-gold-300">Masuk di sini</Link>
        </div>
      </div>
    </div>
  )
}
