import { useState } from 'react'
import { Link, useNavigate } from 'react-router-dom'
import { Eye, EyeOff, UserPlus } from 'lucide-react'
import { useAuth } from '../lib/auth'
import { Alert } from '../components/ui'
import { COMPETITIONS } from '../lib/data'

export default function Register() {
  const { register } = useAuth()
  const navigate = useNavigate()

  const [form, setForm] = useState({
    name: '', email: '', password: '', confirm: '',
    university: '', nim: '', phone: '',
    competition: '',
  })
  const [showPw, setShowPw] = useState(false)
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState('')

  const set = (k, v) => setForm(p => ({ ...p, [k]: v }))

  const handleSubmit = async (e) => {
    e.preventDefault()
    setError('')
    if (form.password !== form.confirm) {
      setError('Password tidak cocok.')
      return
    }
    if (form.password.length < 8) {
      setError('Password minimal 8 karakter.')
      return
    }
    setLoading(true)
    try {
      await register({
        name: form.name,
        email: form.email,
        password: form.password,
        university: form.university,
        nim: form.nim,
        phone: form.phone,
        competition: form.competition,
      })
      navigate('/dashboard')
    } catch (err) {
      setError(err.message)
    } finally {
      setLoading(false)
    }
  }

  const Field = ({ label, name, type = 'text', placeholder, required = true, children }) => (
    <div>
      <label className="label">{label}{required && <span className="text-red-400 ml-1">*</span>}</label>
      {children || (
        <input
          type={type}
          className="input"
          placeholder={placeholder}
          value={form[name]}
          onChange={e => set(name, e.target.value)}
          required={required}
        />
      )}
    </div>
  )

  return (
    <div className="min-h-screen bg-navy-900 flex items-center justify-center px-4 py-12">
      <div className="absolute inset-0 overflow-hidden pointer-events-none">
        <div className="absolute top-1/4 right-1/4 w-80 h-80 bg-gold-500/5 rounded-full blur-3xl" />
        <div className="absolute bottom-1/4 left-1/4 w-60 h-60 bg-purple-500/5 rounded-full blur-3xl" />
      </div>

      <div className="relative w-full max-w-lg">
        <div className="text-center mb-8">
          <Link to="/" className="inline-flex flex-col items-center gap-2">
            <div className="w-12 h-12 rounded-full bg-gold-500/20 border border-gold-500/50 flex items-center justify-center">
              <span className="font-display font-black text-gold-400 text-lg">K6</span>
            </div>
            <span className="font-display font-bold text-white text-xl">KARISMA <span className="text-gradient">6</span></span>
          </Link>
          <p className="text-gray-400 mt-2 text-sm">Buat akun peserta baru</p>
        </div>

        <div className="card">
          <h2 className="font-display font-bold text-white text-xl mb-6">Daftar Peserta</h2>

          {error && <Alert type="error" className="mb-5">{error}</Alert>}

          <form onSubmit={handleSubmit} className="space-y-4">
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <Field label="Nama Lengkap" name="name" placeholder="Nama sesuai KTM" />
              <Field label="NIM" name="nim" placeholder="Nomor Induk Mahasiswa" />
            </div>

            <Field label="Email Aktif" name="email" type="email" placeholder="email@kampus.ac.id" />
            <Field label="No. WhatsApp" name="phone" placeholder="08xxxxxxxxxx" />
            <Field label="Asal Perguruan Tinggi" name="university" placeholder="Nama universitas/institut" />

            <div>
              <label className="label">Kategori Lomba <span className="text-red-400">*</span></label>
              <select
                className="input"
                value={form.competition}
                onChange={e => set('competition', e.target.value)}
                required
              >
                <option value="" disabled>Pilih kategori lomba...</option>
                {COMPETITIONS.map(c => (
                  <option key={c.id} value={c.id}>{c.name}</option>
                ))}
              </select>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div>
                <label className="label">Password <span className="text-red-400">*</span></label>
                <div className="relative">
                  <input
                    type={showPw ? 'text' : 'password'}
                    className="input pr-10"
                    placeholder="Min. 8 karakter"
                    value={form.password}
                    onChange={e => set('password', e.target.value)}
                    required
                    minLength={8}
                  />
                  <button type="button" className="absolute right-3 top-1/2 -translate-y-1/2 text-gray-500 hover:text-gray-300" onClick={() => setShowPw(!showPw)}>
                    {showPw ? <EyeOff size={16} /> : <Eye size={16} />}
                  </button>
                </div>
              </div>

              <div>
                <label className="label">Konfirmasi Password <span className="text-red-400">*</span></label>
                <input
                  type={showPw ? 'text' : 'password'}
                  className="input"
                  placeholder="Ulangi password"
                  value={form.confirm}
                  onChange={e => set('confirm', e.target.value)}
                  required
                />
              </div>
            </div>

            <div className="text-xs text-gray-500 bg-navy-700 rounded-lg p-3">
              Dengan mendaftar, kamu menyetujui <span className="text-gold-400">syarat & ketentuan</span> KARISMA 6 yang berlaku.
            </div>

            <button type="submit" className="btn-primary w-full justify-center py-3.5" disabled={loading}>
              {loading ? (
                <div className="w-5 h-5 border-2 border-navy-900/30 border-t-navy-900 rounded-full animate-spin" />
              ) : (
                <>
                  <UserPlus size={16} />
                  Buat Akun
                </>
              )}
            </button>
          </form>

          <p className="text-center text-gray-400 text-sm mt-6">
            Sudah punya akun?{' '}
            <Link to="/login" className="text-gold-400 hover:text-gold-300 font-medium">Masuk di sini</Link>
          </p>
        </div>
      </div>
    </div>
  )
}
