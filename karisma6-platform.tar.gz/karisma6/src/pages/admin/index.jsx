import { useState, useEffect } from 'react'
import { Download, CheckCircle, XCircle, Eye } from 'lucide-react'
import DashboardLayout from '../../components/layout/DashboardLayout'
import { fetchAllRegistrations, fetchPaymentRecap, formatCurrency, formatDate } from '../../lib/data'
import { StatusBadge, Spinner, PageHeader, StatsCard, Table, Modal } from '../../components/ui'

// ─── Admin Payment Recap ──────────────────────────────────────────────────────
export function AdminPaymentRecap() {
  const [registrations, setRegistrations] = useState([])
  const [recap, setRecap] = useState(null)
  const [loading, setLoading] = useState(true)
  const [search, setSearch] = useState('')
  const [statusFilter, setStatusFilter] = useState('all')
  const [selected, setSelected] = useState(null)

  useEffect(() => {
    Promise.all([fetchAllRegistrations(), fetchPaymentRecap()])
      .then(([r, p]) => { setRegistrations(r); setRecap(p) })
      .finally(() => setLoading(false))
  }, [])

  const filtered = registrations.filter(r => {
    const matchSearch = r.name.toLowerCase().includes(search.toLowerCase()) ||
      r.university.toLowerCase().includes(search.toLowerCase()) ||
      r.id.toLowerCase().includes(search.toLowerCase())
    const matchStatus = statusFilter === 'all' || r.payment === statusFilter
    return matchSearch && matchStatus
  })

  return (
    <DashboardLayout>
      <PageHeader
        title="Rekap Pembayaran"
        description="Kelola dan verifikasi pembayaran peserta KARISMA 6."
        action={
          <button className="btn-primary text-sm py-2">
            <Download size={14} /> Export Excel
          </button>
        }
      />

      {loading ? (
        <div className="flex justify-center py-16"><Spinner /></div>
      ) : (
        <>
          {/* Stats */}
          {recap && (
            <div className="grid grid-cols-2 lg:grid-cols-4 gap-4 mb-8">
              <StatsCard label="Total Masuk" value={formatCurrency(recap.total)} icon="💰" />
              <StatsCard label="Terverifikasi" value={formatCurrency(recap.verified)} icon="✅" color="text-green-400" />
              <StatsCard label="Menunggu Verifikasi" value={recap.count.pending.toString()} icon="⏳" color="text-yellow-400" />
              <StatsCard label="Ditolak" value={recap.count.rejected.toString()} icon="❌" color="text-red-400" />
            </div>
          )}

          {/* Filters */}
          <div className="card mb-5">
            <div className="flex flex-col sm:flex-row gap-3">
              <input
                className="input flex-1"
                placeholder="Cari nama tim, universitas, atau ID..."
                value={search}
                onChange={e => setSearch(e.target.value)}
              />
              <select
                className="input sm:w-48"
                value={statusFilter}
                onChange={e => setStatusFilter(e.target.value)}
              >
                <option value="all">Semua Status</option>
                <option value="verified">Terverifikasi</option>
                <option value="pending">Menunggu</option>
                <option value="unverified">Belum Verifikasi</option>
              </select>
            </div>
          </div>

          {/* Table */}
          <div className="card">
            <Table
              columns={[
                { header: 'ID', key: 'id' },
                { header: 'Tim', key: 'name' },
                { header: 'Universitas', key: 'university' },
                { header: 'Lomba', key: 'competition' },
                { header: 'Status', render: r => <StatusBadge status={r.status} /> },
                { header: 'Pembayaran', render: r => <StatusBadge status={r.payment} /> },
                {
                  header: 'Aksi',
                  render: r => (
                    <div className="flex gap-2">
                      <button onClick={() => setSelected(r)} className="p-1.5 text-gray-400 hover:text-white rounded hover:bg-white/10">
                        <Eye size={14} />
                      </button>
                      {r.payment !== 'verified' && (
                        <button className="p-1.5 text-green-400 hover:text-green-300 rounded hover:bg-green-500/10">
                          <CheckCircle size={14} />
                        </button>
                      )}
                      {r.payment !== 'unverified' && r.payment !== 'rejected' && (
                        <button className="p-1.5 text-red-400 hover:text-red-300 rounded hover:bg-red-500/10">
                          <XCircle size={14} />
                        </button>
                      )}
                    </div>
                  )
                },
              ]}
              data={filtered}
              emptyMessage="Tidak ada data yang sesuai filter."
            />
          </div>
        </>
      )}

      {/* Detail modal */}
      <Modal open={!!selected} onClose={() => setSelected(null)} title="Detail Registrasi">
        {selected && (
          <div className="space-y-3 text-sm">
            {[
              ['ID', selected.id],
              ['Nama Tim', selected.name],
              ['Universitas', selected.university],
              ['Lomba', selected.competition],
              ['Tanggal Daftar', formatDate(selected.date)],
            ].map(([label, value]) => (
              <div key={label} className="flex justify-between">
                <span className="text-gray-400">{label}</span>
                <span className="text-white font-medium">{value}</span>
              </div>
            ))}
            <div className="flex justify-between items-center">
              <span className="text-gray-400">Status</span>
              <StatusBadge status={selected.status} />
            </div>
            <div className="flex justify-between items-center">
              <span className="text-gray-400">Pembayaran</span>
              <StatusBadge status={selected.payment} />
            </div>
            <div className="flex gap-3 mt-4 pt-4 border-t border-white/10">
              <button className="btn-primary flex-1 justify-center text-sm py-2">
                <CheckCircle size={14} /> Verifikasi
              </button>
              <button className="flex-1 border border-red-500/40 text-red-400 rounded-lg py-2 text-sm hover:bg-red-500/10 transition-colors flex items-center justify-center gap-2">
                <XCircle size={14} /> Tolak
              </button>
            </div>
          </div>
        )}
      </Modal>
    </DashboardLayout>
  )
}

// ─── Admin Certificates ───────────────────────────────────────────────────────
export function AdminCertificates() {
  const [registrations, setRegistrations] = useState([])
  const [loading, setLoading] = useState(true)
  const [generating, setGenerating] = useState(null)

  useEffect(() => {
    fetchAllRegistrations().then(setRegistrations).finally(() => setLoading(false))
  }, [])

  const approved = registrations.filter(r => r.status === 'approved')

  const handleGenerate = async (id) => {
    setGenerating(id)
    await new Promise(r => setTimeout(r, 1500))
    setGenerating(null)
    alert(`Sertifikat untuk ${id} berhasil digenerate! (Simulasi)`)
  }

  return (
    <DashboardLayout>
      <PageHeader
        title="Kelola Sertifikat"
        description="Generate dan distribusikan sertifikat peserta."
        action={
          <button className="btn-primary text-sm py-2" onClick={() => handleGenerate('all')}>
            Generate Semua
          </button>
        }
      />

      {loading ? (
        <div className="flex justify-center py-16"><Spinner /></div>
      ) : (
        <div className="card">
          <p className="text-sm text-gray-400 mb-5">{approved.length} peserta dengan status disetujui siap menerima sertifikat.</p>
          <Table
            columns={[
              { header: 'ID', key: 'id' },
              { header: 'Tim', key: 'name' },
              { header: 'Universitas', key: 'university' },
              { header: 'Lomba', key: 'competition' },
              {
                header: 'Aksi',
                render: r => (
                  <button
                    onClick={() => handleGenerate(r.id)}
                    disabled={generating === r.id}
                    className="btn-primary text-xs py-1.5 px-3"
                  >
                    {generating === r.id
                      ? <div className="w-3 h-3 border border-navy-900/30 border-t-navy-900 rounded-full animate-spin" />
                      : <><Download size={12} /> Generate</>}
                  </button>
                )
              },
            ]}
            data={approved}
            emptyMessage="Belum ada peserta yang disetujui."
          />
        </div>
      )}
    </DashboardLayout>
  )
}
