import { useEffect, useState } from 'react'
import { Link } from 'react-router-dom'
import { ArrowRight, CheckCircle, Clock, XCircle, AlertCircle } from 'lucide-react'
import DashboardLayout from '../../components/layout/DashboardLayout'
import { useAuth } from '../../lib/auth'
import { fetchParticipantData, COMPETITIONS, formatCurrency, formatDate } from '../../lib/data'
import { StatusBadge, Spinner, PageHeader, StatsCard } from '../../components/ui'

function StepItem({ number, label, status, to }) {
  const icons = {
    approved: <CheckCircle size={16} className="text-green-400" />,
    verified: <CheckCircle size={16} className="text-green-400" />,
    pending: <Clock size={16} className="text-yellow-400" />,
    rejected: <XCircle size={16} className="text-red-400" />,
    default: <AlertCircle size={16} className="text-gray-500" />,
  }
  const icon = icons[status] || icons.default

  return (
    <Link to={to} className="flex items-center gap-4 p-4 rounded-xl border border-white/10 hover:border-gold-500/30 hover:bg-white/5 transition-all group">
      <div className="w-8 h-8 rounded-full bg-navy-700 border border-white/10 flex items-center justify-center text-xs font-bold text-gray-400 flex-shrink-0">
        {number}
      </div>
      <div className="flex-1 min-w-0">
        <p className="text-sm font-medium text-white">{label}</p>
      </div>
      {icon}
      <ArrowRight size={14} className="text-gray-600 group-hover:text-gray-400 transition-colors" />
    </Link>
  )
}

export default function Dashboard() {
  const { user } = useAuth()
  const [data, setData] = useState(null)
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    fetchParticipantData(user?.id).then(setData).finally(() => setLoading(false))
  }, [user])

  if (loading) {
    return (
      <DashboardLayout>
        <div className="flex items-center justify-center h-64">
          <Spinner size="lg" />
        </div>
      </DashboardLayout>
    )
  }

  const comp = data?.registration ? COMPETITIONS.find(c => c.id === data.registration.competition) : null

  return (
    <DashboardLayout>
      <PageHeader
        title={`Halo, ${user?.name?.split(' ')[0]}! 👋`}
        description="Selamat datang di portal peserta KARISMA 6."
      />

      {/* Competition card */}
      {comp && (
        <div className={`card mb-8 border ${comp.border} bg-gradient-to-br ${comp.color}`}>
          <div className="flex items-start gap-4">
            <div className="text-3xl">{comp.icon}</div>
            <div className="flex-1 min-w-0">
              <p className="text-xs text-gray-400 uppercase tracking-wider mb-1">Kategori Terdaftar</p>
              <h3 className="font-display font-bold text-white text-lg mb-1">{comp.name}</h3>
              <p className="text-sm text-gray-400 mb-3">
                Tim: <span className="text-white">{data.registration.teamName}</span>
                {' · '}{data.registration.members.length} anggota
              </p>
              <StatusBadge status={data.registration.status} />
            </div>
            <div className="text-right flex-shrink-0">
              <p className="text-xs text-gray-500">{data.registration.id}</p>
              <p className="text-xs text-gray-500 mt-1">{formatDate(data.registration.registeredAt)}</p>
            </div>
          </div>
        </div>
      )}

      {/* Progress steps */}
      <div className="mb-8">
        <h2 className="font-semibold text-white mb-4 flex items-center gap-2">
          <span className="w-1 h-5 bg-gold-500 rounded-full inline-block" />
          Progres Partisipasi
        </h2>
        <div className="grid gap-2">
          <StepItem number="1" label="Registrasi Tim" status={data?.registration?.status} to="/dashboard/registration" />
          <StepItem number="2" label="Konfirmasi Pembayaran" status={data?.payment?.status} to="/dashboard/payment" />
          <StepItem number="3" label="Pengumpulan Karya" status={data?.submission?.status} to="/dashboard/submission" />
          <StepItem number="4" label="Sertifikat" status={data?.certificate?.available ? 'approved' : 'default'} to="/dashboard/certificate" />
        </div>
      </div>

      {/* Quick stats */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
        <StatsCard label="Status Registrasi" value="✅" trend={data?.registration?.status === 'approved' ? 'Disetujui' : 'Menunggu'} />
        <StatsCard label="Pembayaran" value={data?.payment?.status === 'verified' ? '✅' : '⏳'} trend={data?.payment?.status === 'verified' ? 'Terverifikasi' : 'Belum Bayar'} />
        <StatsCard label="Submisi" value="📝" trend={data?.submission?.status === 'submitted' ? 'Sudah Dikumpul' : 'Belum Dikumpul'} />
        <StatsCard label="Sertifikat" value={data?.certificate?.available ? '🏅' : '🔒'} trend={data?.certificate?.available ? 'Tersedia' : 'Belum Tersedia'} />
      </div>
    </DashboardLayout>
  )
}
