import { useState, useEffect } from 'react'
import { Upload, CheckCircle, Download, Bell, FileText } from 'lucide-react'
import DashboardLayout from '../../components/layout/DashboardLayout'
import { useAuth } from '../../lib/auth'
import {
  fetchParticipantData, submitPaymentProof, submitWork,
  COMPETITIONS, ANNOUNCEMENTS, formatCurrency, formatDate
} from '../../lib/data'
import { Alert, StatusBadge, Spinner, PageHeader, EmptyState } from '../../components/ui'

// ─── Registration Page ────────────────────────────────────────────────────────
export function DashboardRegistration() {
  const { user } = useAuth()
  const [data, setData] = useState(null)
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    fetchParticipantData(user?.id).then(d => setData(d)).finally(() => setLoading(false))
  }, [user])

  const comp = data?.registration ? COMPETITIONS.find(c => c.id === data.registration.competition) : null

  return (
    <DashboardLayout>
      <PageHeader title="Registrasi" description="Detail pendaftaran tim Anda." />
      {loading ? (
        <div className="flex justify-center py-16"><Spinner /></div>
      ) : data?.registration ? (
        <div className="space-y-5">
          <div className="card">
            <div className="flex items-center justify-between mb-5">
              <h3 className="font-display font-bold text-white">Informasi Tim</h3>
              <StatusBadge status={data.registration.status} />
            </div>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 text-sm">
              {[
                ['ID Registrasi', data.registration.id],
                ['Nama Tim', data.registration.teamName],
                ['Tanggal Daftar', formatDate(data.registration.registeredAt)],
                ['Kategori Lomba', comp?.name || data.registration.competition],
              ].map(([label, value]) => (
                <div key={label} className="bg-navy-700/50 rounded-lg p-3">
                  <p className="text-gray-500 text-xs mb-1">{label}</p>
                  <p className="text-white font-medium">{value}</p>
                </div>
              ))}
            </div>
          </div>
          <div className="card">
            <h3 className="font-semibold text-white mb-4">Anggota Tim</h3>
            <div className="space-y-3">
              {data.registration.members.map((m, i) => (
                <div key={i} className="flex items-center gap-3 p-3 bg-navy-700/50 rounded-lg">
                  <div className="w-8 h-8 rounded-full bg-gold-500/20 border border-gold-500/30 flex items-center justify-center text-gold-400 text-xs font-bold">
                    {i + 1}
                  </div>
                  <div>
                    <p className="text-white text-sm font-medium">{m}</p>
                    {i === 0 && <p className="text-xs text-gold-400">Ketua Tim</p>}
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      ) : (
        <EmptyState
          icon="📋"
          title="Belum Ada Registrasi"
          description="Anda belum terdaftar di kompetisi manapun."
          action={<a href="/registration" className="btn-primary">Daftar Sekarang</a>}
        />
      )}
    </DashboardLayout>
  )
}

// ─── Payment Page ─────────────────────────────────────────────────────────────
export function DashboardPayment() {
  const { user } = useAuth()
  const [data, setData] = useState(null)
  const [loading, setLoading] = useState(true)
  const [file, setFile] = useState(null)
  const [uploading, setUploading] = useState(false)
  const [success, setSuccess] = useState('')
  const [error, setError] = useState('')

  useEffect(() => {
    fetchParticipantData(user?.id).then(setData).finally(() => setLoading(false))
  }, [user])

  const handleUpload = async () => {
    if (!file) return
    setUploading(true)
    setError('')
    try {
      await submitPaymentProof(file)
      setSuccess('Bukti pembayaran berhasil diunggah. Tim kami akan memverifikasi dalam 1×24 jam.')
      setFile(null)
    } catch (e) {
      setError(e.message)
    } finally {
      setUploading(false)
    }
  }

  const comp = data?.registration ? COMPETITIONS.find(c => c.id === data.registration.competition) : null

  return (
    <DashboardLayout>
      <PageHeader title="Pembayaran" description="Upload bukti transfer biaya pendaftaran." />
      {loading ? (
        <div className="flex justify-center py-16"><Spinner /></div>
      ) : (
        <div className="space-y-5">
          {/* Payment status */}
          <div className="card">
            <div className="flex items-center justify-between mb-4">
              <h3 className="font-display font-bold text-white">Status Pembayaran</h3>
              <StatusBadge status={data?.payment?.status || 'pending'} />
            </div>
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 text-sm">
              <div className="bg-navy-700/50 rounded-lg p-3">
                <p className="text-gray-500 text-xs mb-1">Jumlah</p>
                <p className="text-gold-400 font-bold text-lg">{formatCurrency(comp?.fee || 0)}</p>
              </div>
              <div className="bg-navy-700/50 rounded-lg p-3">
                <p className="text-gray-500 text-xs mb-1">Metode</p>
                <p className="text-white">{data?.payment?.method || '—'}</p>
              </div>
              <div className="bg-navy-700/50 rounded-lg p-3">
                <p className="text-gray-500 text-xs mb-1">Terverifikasi</p>
                <p className="text-white">{data?.payment?.verifiedAt ? formatDate(data.payment.verifiedAt) : '—'}</p>
              </div>
            </div>
          </div>

          {/* Bank info */}
          <div className="card border-gold-500/20 bg-gold-500/5">
            <h3 className="font-semibold text-white mb-3">Informasi Rekening Tujuan</h3>
            <div className="space-y-2 text-sm">
              {[
                ['Bank', 'BNI'],
                ['Nomor Rekening', '0123456789'],
                ['Atas Nama', 'HMJ SSP UNDIKSHA'],
                ['Nominal', formatCurrency(comp?.fee || 0)],
                ['Berita Transfer', data?.registration?.id || 'REG-ID Anda'],
              ].map(([label, value]) => (
                <div key={label} className="flex justify-between">
                  <span className="text-gray-400">{label}</span>
                  <span className="text-white font-medium">{value}</span>
                </div>
              ))}
            </div>
          </div>

          {/* Upload form */}
          {data?.payment?.status !== 'verified' && (
            <div className="card">
              <h3 className="font-semibold text-white mb-4">Upload Bukti Pembayaran</h3>
              {success && <Alert type="success" className="mb-4">{success}</Alert>}
              {error && <Alert type="error" className="mb-4">{error}</Alert>}
              <div
                className="border-2 border-dashed border-white/20 rounded-xl p-8 text-center hover:border-gold-500/40 transition-colors cursor-pointer"
                onClick={() => document.getElementById('file-upload').click()}
              >
                <Upload size={32} className="mx-auto text-gray-500 mb-3" />
                <p className="text-gray-400 text-sm">{file ? file.name : 'Klik atau seret file ke sini'}</p>
                <p className="text-gray-600 text-xs mt-1">PNG, JPG, PDF — maks. 5MB</p>
                <input id="file-upload" type="file" className="hidden" accept="image/*,.pdf" onChange={e => setFile(e.target.files[0])} />
              </div>
              <button
                className="btn-primary w-full justify-center mt-4"
                onClick={handleUpload}
                disabled={!file || uploading}
              >
                {uploading ? <div className="w-5 h-5 border-2 border-navy-900/30 border-t-navy-900 rounded-full animate-spin" /> : <><Upload size={16} /> Kirim Bukti Pembayaran</>}
              </button>
            </div>
          )}
        </div>
      )}
    </DashboardLayout>
  )
}

// ─── Submission Page ──────────────────────────────────────────────────────────
export function DashboardSubmission() {
  const { user } = useAuth()
  const [data, setData] = useState(null)
  const [loading, setLoading] = useState(true)
  const [files, setFiles] = useState([])
  const [notes, setNotes] = useState('')
  const [submitting, setSubmitting] = useState(false)
  const [success, setSuccess] = useState('')
  const [error, setError] = useState('')

  useEffect(() => {
    fetchParticipantData(user?.id).then(setData).finally(() => setLoading(false))
  }, [user])

  const handleSubmit = async () => {
    if (files.length === 0) { setError('Pilih file karya terlebih dahulu.'); return }
    setSubmitting(true)
    setError('')
    try {
      await submitWork(files, notes)
      setSuccess('Karya berhasil dikumpulkan! Panitia akan meninjau dalam beberapa hari.')
      setFiles([])
    } catch (e) {
      setError(e.message)
    } finally {
      setSubmitting(false)
    }
  }

  return (
    <DashboardLayout>
      <PageHeader
        title="Submisi Karya"
        description={data?.submission?.deadline ? `Batas pengumpulan: ${formatDate(data.submission.deadline)}` : 'Kumpulkan karya Anda sebelum batas waktu.'}
      />
      {loading ? (
        <div className="flex justify-center py-16"><Spinner /></div>
      ) : (
        <div className="space-y-5">
          {data?.payment?.status !== 'verified' && (
            <Alert type="warning">Pembayaran belum terverifikasi. Anda baru bisa mengumpulkan karya setelah pembayaran dikonfirmasi.</Alert>
          )}
          <div className="card">
            <div className="flex items-center justify-between mb-5">
              <h3 className="font-display font-bold text-white">Upload Karya</h3>
              <StatusBadge status={data?.submission?.status || 'pending'} />
            </div>
            {success && <Alert type="success" className="mb-4">{success}</Alert>}
            {error && <Alert type="error" className="mb-4">{error}</Alert>}
            <div className="space-y-4">
              <div>
                <label className="label">File Karya</label>
                <div
                  className="border-2 border-dashed border-white/20 rounded-xl p-8 text-center hover:border-gold-500/40 transition-colors cursor-pointer"
                  onClick={() => document.getElementById('work-upload').click()}
                >
                  <FileText size={32} className="mx-auto text-gray-500 mb-3" />
                  {files.length > 0 ? (
                    <p className="text-gray-300 text-sm">{files.length} file dipilih: {Array.from(files).map(f => f.name).join(', ')}</p>
                  ) : (
                    <>
                      <p className="text-gray-400 text-sm">Klik untuk pilih file karya</p>
                      <p className="text-gray-600 text-xs mt-1">PDF, DOC, ZIP — maks. 50MB</p>
                    </>
                  )}
                  <input id="work-upload" type="file" className="hidden" multiple onChange={e => setFiles(e.target.files)} />
                </div>
              </div>
              <div>
                <label className="label">Catatan (opsional)</label>
                <textarea
                  className="input h-24 resize-none"
                  placeholder="Catatan tambahan untuk panitia..."
                  value={notes}
                  onChange={e => setNotes(e.target.value)}
                />
              </div>
              <button
                className="btn-primary w-full justify-center"
                onClick={handleSubmit}
                disabled={submitting || data?.payment?.status !== 'verified'}
              >
                {submitting ? <div className="w-5 h-5 border-2 border-navy-900/30 border-t-navy-900 rounded-full animate-spin" /> : <><Upload size={16} /> Kumpulkan Karya</>}
              </button>
            </div>
          </div>
          {data?.submission?.feedback && (
            <div className="card border-blue-500/30 bg-blue-500/5">
              <h3 className="font-semibold text-white mb-2 flex items-center gap-2"><Bell size={16} /> Feedback Juri</h3>
              <p className="text-gray-300 text-sm">{data.submission.feedback}</p>
            </div>
          )}
        </div>
      )}
    </DashboardLayout>
  )
}

// ─── Certificate Page ─────────────────────────────────────────────────────────
export function DashboardCertificate() {
  const { user } = useAuth()
  const [data, setData] = useState(null)
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    fetchParticipantData(user?.id).then(setData).finally(() => setLoading(false))
  }, [user])

  return (
    <DashboardLayout>
      <PageHeader title="Sertifikat" description="Download sertifikat partisipasi Anda." />
      {loading ? (
        <div className="flex justify-center py-16"><Spinner /></div>
      ) : data?.certificate?.available ? (
        <div className="space-y-5">
          <Alert type="success">Sertifikat Anda sudah tersedia! Silakan download di bawah ini.</Alert>
          <div className="card text-center py-12">
            <div className="w-20 h-20 rounded-full bg-gold-500/20 border border-gold-500/50 flex items-center justify-center mx-auto mb-5">
              <CheckCircle size={36} className="text-gold-400" />
            </div>
            <h3 className="font-display font-bold text-white text-2xl mb-2">Selamat! 🎉</h3>
            <p className="text-gray-400 mb-6">{user?.name} · KARISMA 6 · 2025</p>
            <a href={data.certificate.url} className="btn-primary inline-flex mx-auto" download>
              <Download size={16} /> Download Sertifikat PDF
            </a>
          </div>
        </div>
      ) : (
        <EmptyState
          icon="🏅"
          title="Sertifikat Belum Tersedia"
          description="Sertifikat akan tersedia setelah seluruh rangkaian KARISMA 6 selesai. Pantau terus pengumuman untuk info lebih lanjut."
        />
      )}
    </DashboardLayout>
  )
}

// ─── Announcements Page ───────────────────────────────────────────────────────
export function DashboardAnnouncements() {
  const [filter, setFilter] = useState('Semua')
  const categories = ['Semua', ...new Set(ANNOUNCEMENTS.map(a => a.category))]

  const filtered = filter === 'Semua' ? ANNOUNCEMENTS : ANNOUNCEMENTS.filter(a => a.category === filter)

  return (
    <DashboardLayout>
      <PageHeader title="Pengumuman" description="Informasi dan pemberitahuan terbaru dari panitia." />

      <div className="flex gap-2 flex-wrap mb-6">
        {categories.map(cat => (
          <button
            key={cat}
            onClick={() => setFilter(cat)}
            className={`px-3 py-1.5 rounded-lg text-xs font-medium transition-colors ${
              filter === cat ? 'bg-gold-500 text-navy-900' : 'bg-navy-700 text-gray-400 hover:text-white'
            }`}
          >
            {cat}
          </button>
        ))}
      </div>

      <div className="space-y-4">
        {filtered.map(a => (
          <div key={a.id} className={`card ${a.pinned ? 'border-gold-500/30 bg-gold-500/5' : ''}`}>
            <div className="flex flex-wrap items-center gap-2 mb-3">
              {a.pinned && <span className="badge badge-gold">📌 Disematkan</span>}
              <span className="badge badge-info">{a.category}</span>
              <span className="text-xs text-gray-500 ml-auto">{formatDate(a.date)}</span>
            </div>
            <h3 className="font-semibold text-white mb-2">{a.title}</h3>
            <p className="text-gray-400 text-sm leading-relaxed">{a.content}</p>
          </div>
        ))}
      </div>
    </DashboardLayout>
  )
}
