import { Link } from 'react-router-dom'
import { ArrowRight, Calendar, MapPin, Trophy, ChevronDown } from 'lucide-react'
import Navbar from '../components/layout/Navbar'
import { COMPETITIONS, TIMELINE, STATS, ANNOUNCEMENTS } from '../lib/data'
import { StatusBadge } from '../components/ui'

export default function Home() {
  return (
    <div className="min-h-screen bg-navy-900">
      <Navbar />

      {/* ── Hero ─────────────────────────────────────────────────────────── */}
      <section className="relative min-h-screen flex items-center justify-center overflow-hidden pt-16">
        {/* Animated background */}
        <div className="absolute inset-0">
          <div className="absolute inset-0 bg-hero-gradient" />
          <div className="absolute top-1/4 left-1/4 w-96 h-96 bg-gold-500/5 rounded-full blur-3xl animate-float" />
          <div className="absolute bottom-1/3 right-1/4 w-72 h-72 bg-purple-500/5 rounded-full blur-3xl animate-float" style={{ animationDelay: '1.5s' }} />
          {/* Stars */}
          {[...Array(30)].map((_, i) => (
            <div
              key={i}
              className="absolute w-0.5 h-0.5 bg-white/30 rounded-full"
              style={{
                top: `${Math.random() * 100}%`,
                left: `${Math.random() * 100}%`,
                animationDelay: `${Math.random() * 3}s`,
                animationDuration: `${2 + Math.random() * 3}s`,
              }}
            />
          ))}
        </div>

        <div className="relative max-w-5xl mx-auto px-4 text-center">
          {/* Badge */}
          <div className="inline-flex items-center gap-2 bg-gold-500/10 border border-gold-500/30 rounded-full px-4 py-1.5 text-sm text-gold-400 mb-8">
            <span className="w-2 h-2 bg-gold-400 rounded-full animate-pulse" />
            Pendaftaran Dibuka · 2025
          </div>

          {/* Title */}
          <h1 className="font-display font-black text-5xl sm:text-6xl md:text-8xl text-white leading-tight mb-4">
            KARISMA{' '}
            <span className="text-gradient">6</span>
          </h1>

          <p className="text-gold-400/80 font-display text-lg sm:text-xl tracking-widest mb-6 uppercase">
            Karya · Inovasi · Prestasi
          </p>

          <p className="text-gray-400 text-lg sm:text-xl max-w-2xl mx-auto mb-4 leading-relaxed">
            Kompetisi ilmiah mahasiswa tingkat nasional yang diselenggarakan oleh{' '}
            <span className="text-white font-medium">HMJ SSP Undiksha</span>
          </p>

          <div className="flex items-center justify-center gap-2 text-gray-500 text-sm mb-10">
            <MapPin size={14} />
            <span>Universitas Pendidikan Ganesha, Singaraja, Bali</span>
            <span className="mx-2">·</span>
            <Calendar size={14} />
            <span>April 2025</span>
          </div>

          <div className="flex flex-col sm:flex-row items-center justify-center gap-4">
            <Link to="/register" className="btn-primary text-base px-8 py-4">
              Daftar Sekarang
              <ArrowRight size={18} />
            </Link>
            <a href="#lomba" className="btn-secondary text-base px-8 py-4">
              Lihat Lomba
            </a>
          </div>

          {/* Scroll indicator */}
          <div className="mt-20 flex flex-col items-center text-gray-600 animate-bounce">
            <ChevronDown size={20} />
          </div>
        </div>
      </section>

      {/* ── Stats ──────────────────────────────────────────────────────────── */}
      <section className="py-20 border-y border-white/10">
        <div className="max-w-6xl mx-auto px-4 grid grid-cols-2 md:grid-cols-4 gap-6">
          {STATS.map((s, i) => (
            <div key={i} className="text-center">
              <div className="text-3xl mb-2">{s.icon}</div>
              <div className="text-3xl font-display font-bold text-gradient">{s.value}</div>
              <div className="text-gray-500 text-sm mt-1">{s.label}</div>
            </div>
          ))}
        </div>
      </section>

      {/* ── Competitions ─────────────────────────────────────────────────── */}
      <section id="lomba" className="py-24 max-w-6xl mx-auto px-4">
        <div className="text-center mb-16">
          <p className="text-gold-400 text-sm font-medium tracking-widest uppercase mb-3">Kategori Lomba</p>
          <h2 className="section-title">Pilih Kompetisimu</h2>
          <p className="section-subtitle max-w-xl mx-auto">
            Enam kategori lomba ilmiah bergengsi yang terbuka untuk mahasiswa aktif seluruh Indonesia.
          </p>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-5">
          {COMPETITIONS.map(comp => (
            <div key={comp.id} className={`card-hover bg-gradient-to-br ${comp.color} ${comp.border} group`}>
              <div className="text-3xl mb-3">{comp.icon}</div>
              <div className="text-xs text-gray-500 uppercase tracking-wider mb-2">{comp.category}</div>
              <h3 className="font-display font-bold text-white text-lg mb-2">{comp.name}</h3>
              <p className="text-gray-400 text-sm leading-relaxed mb-4">{comp.description}</p>
              <div className="flex items-center justify-between text-xs text-gray-500">
                <span>Maks. {comp.maxTeam} anggota</span>
                <span>Deadline: {new Date(comp.deadline).toLocaleDateString('id-ID', { day: 'numeric', month: 'short' })}</span>
              </div>
              <div className="mt-4 pt-4 border-t border-white/10 flex items-center justify-between">
                <span className="text-gold-400 font-semibold text-sm">
                  Rp {comp.fee.toLocaleString('id-ID')}
                </span>
                <Link to="/register" className="text-xs text-gold-400 hover:text-gold-300 font-medium flex items-center gap-1">
                  Daftar <ArrowRight size={12} />
                </Link>
              </div>
            </div>
          ))}
        </div>
      </section>

      {/* ── Timeline ─────────────────────────────────────────────────────── */}
      <section id="timeline" className="py-24 bg-navy-800/50 border-y border-white/10">
        <div className="max-w-4xl mx-auto px-4">
          <div className="text-center mb-16">
            <p className="text-gold-400 text-sm font-medium tracking-widest uppercase mb-3">Jadwal Kegiatan</p>
            <h2 className="section-title">Timeline KARISMA 6</h2>
          </div>
          <div className="relative">
            <div className="absolute left-8 top-0 bottom-0 w-px bg-white/10" />
            {TIMELINE.map((t, i) => (
              <div key={i} className="relative flex gap-8 mb-8 last:mb-0">
                <div className="flex-shrink-0 w-16 flex items-start justify-center pt-1">
                  <div className={`w-3 h-3 rounded-full border-2 mt-1 ${
                    t.status === 'active'
                      ? 'bg-gold-500 border-gold-500 shadow-lg shadow-gold-500/50'
                      : 'bg-navy-900 border-white/20'
                  }`} />
                </div>
                <div className="flex-1 card mb-0">
                  <div className="flex flex-wrap items-center gap-3 mb-1">
                    <h3 className="font-semibold text-white">{t.phase}</h3>
                    <StatusBadge status={t.status} />
                  </div>
                  <p className="text-gray-400 text-sm">
                    {t.start === t.end ? t.start : `${t.start} – ${t.end}`}
                  </p>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* ── Announcements preview ─────────────────────────────────────────── */}
      <section className="py-24 max-w-5xl mx-auto px-4">
        <div className="flex items-center justify-between mb-10">
          <div>
            <p className="text-gold-400 text-sm font-medium tracking-widest uppercase mb-2">Info Terkini</p>
            <h2 className="section-title">Pengumuman</h2>
          </div>
          <Link to="/dashboard/announcements" className="btn-ghost text-sm">
            Lihat Semua <ArrowRight size={14} />
          </Link>
        </div>
        <div className="grid gap-4">
          {ANNOUNCEMENTS.slice(0, 3).map(a => (
            <div key={a.id} className={`card ${a.pinned ? 'border-gold-500/30 bg-gold-500/5' : ''}`}>
              <div className="flex flex-wrap items-start gap-3">
                {a.pinned && <span className="badge badge-gold">📌 Utama</span>}
                <span className="badge badge-info">{a.category}</span>
              </div>
              <h3 className="font-semibold text-white mt-3 mb-1">{a.title}</h3>
              <p className="text-gray-400 text-sm line-clamp-2">{a.content}</p>
              <p className="text-xs text-gray-600 mt-3">{new Date(a.date).toLocaleDateString('id-ID', { dateStyle: 'long' })}</p>
            </div>
          ))}
        </div>
      </section>

      {/* ── CTA ──────────────────────────────────────────────────────────── */}
      <section className="py-24 px-4">
        <div className="max-w-3xl mx-auto text-center card border-gold-500/30 bg-gold-500/5 glow-gold">
          <div className="text-5xl mb-4">🏆</div>
          <h2 className="font-display font-bold text-3xl text-white mb-3">
            Siap Menunjukkan Prestasimu?
          </h2>
          <p className="text-gray-400 mb-8 leading-relaxed">
            Bergabunglah dengan ribuan mahasiswa berprestasi dari seluruh Indonesia. Buktikan karya, inovasi, dan kemampuanmu di KARISMA 6.
          </p>
          <div className="flex flex-col sm:flex-row items-center justify-center gap-4">
            <Link to="/register" className="btn-primary px-8 py-4 text-base">
              Daftar Sekarang — Gratis
              <ArrowRight size={18} />
            </Link>
            <Link to="/login" className="btn-ghost">
              Sudah punya akun? Masuk
            </Link>
          </div>
        </div>
      </section>

      {/* ── Footer ───────────────────────────────────────────────────────── */}
      <footer id="kontak" className="border-t border-white/10 py-12 px-4">
        <div className="max-w-6xl mx-auto">
          <div className="flex flex-col md:flex-row items-center justify-between gap-6">
            <div>
              <div className="flex items-center gap-2 mb-2">
                <span className="font-display font-bold text-white text-lg">KARISMA <span className="text-gradient">6</span></span>
              </div>
              <p className="text-gray-500 text-sm">HMJ Sosiologi & Sastra Pendidikan · Undiksha</p>
            </div>
            <div className="flex flex-col items-center gap-1 text-sm text-gray-500">
              <p>📧 karisma6@undiksha.ac.id</p>
              <p>📍 Singaraja, Bali, Indonesia</p>
            </div>
            <p className="text-gray-600 text-xs text-center">
              © 2025 KARISMA 6 · HMJ SSP Undiksha<br />All rights reserved.
            </p>
          </div>
        </div>
      </footer>
    </div>
  )
}
