import { useState } from 'react'
import { Link } from 'react-router-dom'
import { Mail, ArrowLeft, CheckCircle } from 'lucide-react'
import { useAuth } from '../lib/auth'
import { Alert } from '../components/ui'

export function ForgotPassword() {
  const { forgotPassword } = useAuth()
  const [email, setEmail] = useState('')
  const [loading, setLoading] = useState(false)
  const [sent, setSent] = useState(false)
  const [error, setError] = useState('')

  const handleSubmit = async (e) => {
    e.preventDefault()
    setError('')
    setLoading(true)
    try {
      await forgotPassword(email)
      setSent(true)
    } catch (err) {
      setError(err.message)
    } finally {
      setLoading(false)
    }
  }

  return (
    <div className="min-h-screen bg-navy-900 flex items-center justify-center px-4">
      <div className="w-full max-w-md">
        <div className="text-center mb-8">
          <Link to="/" className="inline-block">
            <span className="font-display font-bold text-white text-xl">KARISMA <span className="text-gradient">6</span></span>
          </Link>
        </div>

        <div className="card">
          {sent ? (
            <div className="text-center py-6">
              <CheckCircle size={48} className="text-green-400 mx-auto mb-4" />
              <h2 className="font-display font-bold text-white text-xl mb-3">Email Terkirim!</h2>
              <p className="text-gray-400 text-sm mb-6">
                Link reset password telah dikirim ke <span className="text-white">{email}</span>. Periksa inbox atau folder spam.
              </p>
              <Link to="/login" className="btn-primary w-full justify-center">
                Kembali ke Halaman Masuk
              </Link>
            </div>
          ) : (
            <>
              <div className="mb-6">
                <h2 className="font-display font-bold text-white text-xl mb-2">Lupa Password</h2>
                <p className="text-gray-400 text-sm">Masukkan email terdaftarmu. Kami akan mengirim link reset password.</p>
              </div>

              {error && <Alert type="error" className="mb-5">{error}</Alert>}

              <form onSubmit={handleSubmit} className="space-y-4">
                <div>
                  <label className="label">Email Terdaftar</label>
                  <div className="relative">
                    <Mail size={16} className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-500" />
                    <input
                      type="email"
                      className="input pl-10"
                      placeholder="email@kampus.ac.id"
                      value={email}
                      onChange={e => setEmail(e.target.value)}
                      required
                    />
                  </div>
                </div>
                <button type="submit" className="btn-primary w-full justify-center py-3.5" disabled={loading}>
                  {loading ? (
                    <div className="w-5 h-5 border-2 border-navy-900/30 border-t-navy-900 rounded-full animate-spin" />
                  ) : 'Kirim Link Reset Password'}
                </button>
              </form>

              <div className="mt-5 flex items-center gap-2 text-sm text-gray-400">
                <ArrowLeft size={14} />
                <Link to="/login" className="text-gold-400 hover:text-gold-300">Kembali ke login</Link>
              </div>
            </>
          )}
        </div>
      </div>
    </div>
  )
}

export function ResetPassword() {
  const { resetPassword } = useAuth()
  const [form, setForm] = useState({ password: '', confirm: '' })
  const [loading, setLoading] = useState(false)
  const [done, setDone] = useState(false)
  const [error, setError] = useState('')

  const handleSubmit = async (e) => {
    e.preventDefault()
    if (form.password !== form.confirm) {
      setError('Password tidak cocok.')
      return
    }
    setError('')
    setLoading(true)
    try {
      // token would come from URL query param: new URLSearchParams(location.search).get('token')
      await resetPassword(null, form.password)
      setDone(true)
    } catch (err) {
      setError(err.message)
    } finally {
      setLoading(false)
    }
  }

  return (
    <div className="min-h-screen bg-navy-900 flex items-center justify-center px-4">
      <div className="w-full max-w-md">
        <div className="text-center mb-8">
          <Link to="/" className="inline-block">
            <span className="font-display font-bold text-white text-xl">KARISMA <span className="text-gradient">6</span></span>
          </Link>
        </div>
        <div className="card">
          {done ? (
            <div className="text-center py-6">
              <CheckCircle size={48} className="text-green-400 mx-auto mb-4" />
              <h2 className="font-display font-bold text-white text-xl mb-3">Password Berhasil Diubah</h2>
              <p className="text-gray-400 text-sm mb-6">Silakan masuk dengan password barumu.</p>
              <Link to="/login" className="btn-primary w-full justify-center">Masuk Sekarang</Link>
            </div>
          ) : (
            <>
              <h2 className="font-display font-bold text-white text-xl mb-2">Reset Password</h2>
              <p className="text-gray-400 text-sm mb-6">Buat password baru untuk akunmu.</p>

              {error && <Alert type="error" className="mb-5">{error}</Alert>}

              <form onSubmit={handleSubmit} className="space-y-4">
                <div>
                  <label className="label">Password Baru</label>
                  <input
                    type="password"
                    className="input"
                    placeholder="Min. 8 karakter"
                    value={form.password}
                    onChange={e => setForm(p => ({ ...p, password: e.target.value }))}
                    required minLength={8}
                  />
                </div>
                <div>
                  <label className="label">Konfirmasi Password</label>
                  <input
                    type="password"
                    className="input"
                    placeholder="Ulangi password baru"
                    value={form.confirm}
                    onChange={e => setForm(p => ({ ...p, confirm: e.target.value }))}
                    required
                  />
                </div>
                <button type="submit" className="btn-primary w-full justify-center py-3.5" disabled={loading}>
                  {loading ? <div className="w-5 h-5 border-2 border-navy-900/30 border-t-navy-900 rounded-full animate-spin" /> : 'Simpan Password Baru'}
                </button>
              </form>
            </>
          )}
        </div>
      </div>
    </div>
  )
}
