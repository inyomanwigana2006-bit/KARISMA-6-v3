import { useState } from 'react'
import { Link, useNavigate, useLocation } from 'react-router-dom'
import { Menu, X, LogOut, User, ChevronDown } from 'lucide-react'
import { useAuth } from '../../lib/auth'

export default function Navbar() {
  const { user, logout } = useAuth()
  const navigate = useNavigate()
  const location = useLocation()
  const [menuOpen, setMenuOpen] = useState(false)
  const [userMenuOpen, setUserMenuOpen] = useState(false)

  const handleLogout = () => {
    logout()
    navigate('/')
  }

  const navLinks = [
    { to: '/', label: 'Beranda' },
    { to: '/#lomba', label: 'Lomba' },
    { to: '/#timeline', label: 'Timeline' },
    { to: '/#kontak', label: 'Kontak' },
  ]

  return (
    <nav className="fixed top-0 left-0 right-0 z-50 bg-glass border-b border-white/10">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-16">
          {/* Logo */}
          <Link to="/" className="flex items-center gap-3">
            <div className="w-9 h-9 rounded-full bg-gold-500/20 border border-gold-500/50 flex items-center justify-center">
              <span className="text-gold-400 font-display font-bold text-sm">K6</span>
            </div>
            <span className="font-display font-bold text-white text-lg hidden sm:block">
              KARISMA <span className="text-gradient">6</span>
            </span>
          </Link>

          {/* Desktop nav */}
          <div className="hidden md:flex items-center gap-1">
            {navLinks.map(link => (
              <a
                key={link.to}
                href={link.to}
                className="btn-ghost text-sm"
              >
                {link.label}
              </a>
            ))}
          </div>

          {/* Auth buttons */}
          <div className="hidden md:flex items-center gap-3">
            {user ? (
              <div className="relative">
                <button
                  onClick={() => setUserMenuOpen(!userMenuOpen)}
                  className="flex items-center gap-2 btn-ghost"
                >
                  <div className="w-8 h-8 rounded-full bg-gold-500/20 border border-gold-500/50 flex items-center justify-center">
                    <User size={14} className="text-gold-400" />
                  </div>
                  <span className="text-sm text-gray-300">{user.name.split(' ')[0]}</span>
                  <ChevronDown size={14} className="text-gray-400" />
                </button>

                {userMenuOpen && (
                  <div className="absolute right-0 mt-2 w-48 card shadow-2xl z-50">
                    <div className="pb-2 mb-2 border-b border-white/10">
                      <p className="text-xs text-gray-500">Masuk sebagai</p>
                      <p className="text-sm font-medium text-white truncate">{user.email}</p>
                    </div>
                    <Link
                      to={user.role === 'admin' ? '/admin/payment-recap' : '/dashboard'}
                      onClick={() => setUserMenuOpen(false)}
                      className="block text-sm text-gray-300 hover:text-white py-1.5 transition-colors"
                    >
                      {user.role === 'admin' ? 'Admin Panel' : 'Dashboard'}
                    </Link>
                    <button
                      onClick={handleLogout}
                      className="flex items-center gap-2 text-sm text-red-400 hover:text-red-300 py-1.5 w-full transition-colors mt-1"
                    >
                      <LogOut size={14} />
                      Keluar
                    </button>
                  </div>
                )}
              </div>
            ) : (
              <>
                <Link to="/login" className="btn-ghost text-sm">Masuk</Link>
                <Link to="/register" className="btn-primary text-sm py-2">Daftar Sekarang</Link>
              </>
            )}
          </div>

          {/* Mobile menu btn */}
          <button
            className="md:hidden text-gray-400 hover:text-white p-2"
            onClick={() => setMenuOpen(!menuOpen)}
          >
            {menuOpen ? <X size={20} /> : <Menu size={20} />}
          </button>
        </div>
      </div>

      {/* Mobile menu */}
      {menuOpen && (
        <div className="md:hidden bg-navy-800 border-t border-white/10 px-4 py-4">
          {navLinks.map(link => (
            <a
              key={link.to}
              href={link.to}
              className="block py-2.5 text-gray-300 hover:text-white text-sm"
              onClick={() => setMenuOpen(false)}
            >
              {link.label}
            </a>
          ))}
          <div className="border-t border-white/10 mt-3 pt-3 flex flex-col gap-2">
            {user ? (
              <>
                <Link to={user.role === 'admin' ? '/admin/payment-recap' : '/dashboard'} className="btn-secondary text-sm text-center justify-center" onClick={() => setMenuOpen(false)}>
                  Dashboard
                </Link>
                <button onClick={handleLogout} className="btn-ghost text-sm text-red-400 justify-center">
                  Keluar
                </button>
              </>
            ) : (
              <>
                <Link to="/login" className="btn-secondary text-sm text-center justify-center" onClick={() => setMenuOpen(false)}>Masuk</Link>
                <Link to="/register" className="btn-primary text-sm text-center justify-center" onClick={() => setMenuOpen(false)}>Daftar Sekarang</Link>
              </>
            )}
          </div>
        </div>
      )}
    </nav>
  )
}
