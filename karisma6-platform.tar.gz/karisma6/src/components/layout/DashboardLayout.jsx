import { Link, useLocation, useNavigate } from 'react-router-dom'
import { LayoutDashboard, CreditCard, FileText, Award, Bell, LogOut, ChevronRight, Shield } from 'lucide-react'
import { useAuth } from '../../lib/auth'

const participantLinks = [
  { to: '/dashboard', icon: LayoutDashboard, label: 'Dashboard' },
  { to: '/dashboard/registration', icon: FileText, label: 'Registrasi' },
  { to: '/dashboard/payment', icon: CreditCard, label: 'Pembayaran' },
  { to: '/dashboard/submission', icon: FileText, label: 'Submisi Karya' },
  { to: '/dashboard/certificate', icon: Award, label: 'Sertifikat' },
  { to: '/dashboard/announcements', icon: Bell, label: 'Pengumuman' },
]

const adminLinks = [
  { to: '/admin/payment-recap', icon: CreditCard, label: 'Rekap Pembayaran' },
  { to: '/admin/certificates', icon: Award, label: 'Kelola Sertifikat' },
]

export default function DashboardLayout({ children }) {
  const { user, logout } = useAuth()
  const location = useLocation()
  const navigate = useNavigate()

  const links = user?.role === 'admin' ? adminLinks : participantLinks

  const handleLogout = () => {
    logout()
    navigate('/')
  }

  return (
    <div className="min-h-screen flex bg-navy-900">
      {/* Sidebar */}
      <aside className="w-60 bg-navy-800 border-r border-white/10 flex flex-col fixed h-full z-40">
        {/* Logo */}
        <div className="p-5 border-b border-white/10">
          <Link to="/" className="flex items-center gap-2.5">
            <div className="w-8 h-8 rounded-full bg-gold-500/20 border border-gold-500/50 flex items-center justify-center">
              <span className="text-gold-400 font-display font-bold text-xs">K6</span>
            </div>
            <span className="font-display font-bold text-white text-sm">KARISMA 6</span>
          </Link>
          {user?.role === 'admin' && (
            <div className="mt-2 flex items-center gap-1.5 text-xs text-purple-400">
              <Shield size={11} />
              <span>Admin Panel</span>
            </div>
          )}
        </div>

        {/* User info */}
        <div className="p-4 border-b border-white/10">
          <div className="flex items-center gap-3">
            <div className="w-9 h-9 rounded-full bg-gradient-to-br from-gold-500/30 to-gold-600/20 border border-gold-500/40 flex items-center justify-center text-gold-400 font-bold text-sm">
              {user?.name?.[0] || 'U'}
            </div>
            <div className="min-w-0">
              <p className="text-sm font-medium text-white truncate">{user?.name}</p>
              <p className="text-xs text-gray-500 truncate">{user?.email}</p>
            </div>
          </div>
        </div>

        {/* Nav links */}
        <nav className="flex-1 p-3 overflow-y-auto">
          {links.map(({ to, icon: Icon, label }) => {
            const active = location.pathname === to
            return (
              <Link
                key={to}
                to={to}
                className={`flex items-center gap-3 px-3 py-2.5 rounded-lg mb-0.5 text-sm font-medium transition-all duration-150 group ${
                  active
                    ? 'bg-gold-500/20 text-gold-400 border border-gold-500/30'
                    : 'text-gray-400 hover:text-white hover:bg-white/5'
                }`}
              >
                <Icon size={16} className={active ? 'text-gold-400' : 'text-gray-500 group-hover:text-gray-300'} />
                {label}
                {active && <ChevronRight size={12} className="ml-auto text-gold-400/60" />}
              </Link>
            )
          })}
        </nav>

        {/* Logout */}
        <div className="p-3 border-t border-white/10">
          <button
            onClick={handleLogout}
            className="flex items-center gap-3 px-3 py-2.5 rounded-lg w-full text-sm font-medium text-gray-400 hover:text-red-400 hover:bg-red-500/10 transition-all duration-150"
          >
            <LogOut size={16} />
            Keluar
          </button>
        </div>
      </aside>

      {/* Main content */}
      <main className="flex-1 ml-60 min-h-screen">
        <div className="p-6 md:p-8 max-w-5xl">
          {children}
        </div>
      </main>
    </div>
  )
}
