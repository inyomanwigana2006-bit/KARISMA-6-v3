// ─── Alert ────────────────────────────────────────────────────────────────────
export function Alert({ type = 'info', children, className = '' }) {
  const styles = {
    info: 'bg-blue-500/10 border-blue-500/30 text-blue-300',
    success: 'bg-green-500/10 border-green-500/30 text-green-300',
    warning: 'bg-yellow-500/10 border-yellow-500/30 text-yellow-300',
    error: 'bg-red-500/10 border-red-500/30 text-red-300',
  }
  return (
    <div className={`border rounded-lg p-4 text-sm ${styles[type]} ${className}`}>
      {children}
    </div>
  )
}

// ─── Badge ────────────────────────────────────────────────────────────────────
export function StatusBadge({ status }) {
  const map = {
    pending: { label: 'Menunggu', cls: 'badge-warning' },
    approved: { label: 'Disetujui', cls: 'badge-success' },
    rejected: { label: 'Ditolak', cls: 'badge-danger' },
    verified: { label: 'Terverifikasi', cls: 'badge-success' },
    unverified: { label: 'Belum Verifikasi', cls: 'badge-warning' },
    active: { label: 'Aktif', cls: 'badge-gold' },
    upcoming: { label: 'Akan Datang', cls: 'badge-info' },
    completed: { label: 'Selesai', cls: 'badge-success' },
  }
  const entry = map[status] || { label: status, cls: 'badge-info' }
  return <span className={`badge ${entry.cls}`}>{entry.label}</span>
}

// ─── LoadingSpinner ───────────────────────────────────────────────────────────
export function Spinner({ size = 'md' }) {
  const sizes = { sm: 'w-5 h-5', md: 'w-8 h-8', lg: 'w-12 h-12' }
  return (
    <div className={`${sizes[size]} border-2 border-gold-500/30 border-t-gold-500 rounded-full animate-spin`} />
  )
}

// ─── Empty State ─────────────────────────────────────────────────────────────
export function EmptyState({ icon = '📭', title, description, action }) {
  return (
    <div className="text-center py-16">
      <div className="text-5xl mb-4">{icon}</div>
      <h3 className="text-lg font-semibold text-white mb-2">{title}</h3>
      {description && <p className="text-gray-400 text-sm mb-6 max-w-xs mx-auto">{description}</p>}
      {action}
    </div>
  )
}

// ─── Page Header ─────────────────────────────────────────────────────────────
export function PageHeader({ title, description, action }) {
  return (
    <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4 mb-8">
      <div>
        <h1 className="text-2xl font-display font-bold text-white">{title}</h1>
        {description && <p className="text-gray-400 mt-1 text-sm">{description}</p>}
      </div>
      {action && <div>{action}</div>}
    </div>
  )
}

// ─── Stats Card ───────────────────────────────────────────────────────────────
export function StatsCard({ label, value, icon, trend, color = 'text-gold-400' }) {
  return (
    <div className="card">
      <div className="flex items-start justify-between">
        <div>
          <p className="text-xs font-medium text-gray-500 uppercase tracking-wider">{label}</p>
          <p className={`text-2xl font-bold mt-1 ${color}`}>{value}</p>
          {trend && <p className="text-xs text-gray-500 mt-1">{trend}</p>}
        </div>
        {icon && <span className="text-2xl">{icon}</span>}
      </div>
    </div>
  )
}

// ─── Modal ────────────────────────────────────────────────────────────────────
export function Modal({ open, onClose, title, children }) {
  if (!open) return null
  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
      <div className="absolute inset-0 bg-black/60 backdrop-blur-sm" onClick={onClose} />
      <div className="relative card w-full max-w-md shadow-2xl">
        <div className="flex items-center justify-between mb-4">
          <h3 className="font-display font-bold text-white text-lg">{title}</h3>
          <button onClick={onClose} className="text-gray-400 hover:text-white text-xl leading-none">&times;</button>
        </div>
        {children}
      </div>
    </div>
  )
}

// ─── Table ────────────────────────────────────────────────────────────────────
export function Table({ columns, data, emptyMessage = 'Tidak ada data' }) {
  return (
    <div className="overflow-x-auto">
      <table className="w-full text-sm">
        <thead>
          <tr className="border-b border-white/10">
            {columns.map((col, i) => (
              <th key={i} className="text-left text-xs font-medium text-gray-500 uppercase tracking-wider pb-3 pr-4">
                {col.header}
              </th>
            ))}
          </tr>
        </thead>
        <tbody>
          {data.length === 0 ? (
            <tr>
              <td colSpan={columns.length} className="text-center py-10 text-gray-500">{emptyMessage}</td>
            </tr>
          ) : (
            data.map((row, i) => (
              <tr key={i} className="border-b border-white/5 hover:bg-white/5 transition-colors">
                {columns.map((col, j) => (
                  <td key={j} className="py-3 pr-4 text-gray-300">
                    {col.render ? col.render(row) : row[col.key]}
                  </td>
                ))}
              </tr>
            ))
          )}
        </tbody>
      </table>
    </div>
  )
}
